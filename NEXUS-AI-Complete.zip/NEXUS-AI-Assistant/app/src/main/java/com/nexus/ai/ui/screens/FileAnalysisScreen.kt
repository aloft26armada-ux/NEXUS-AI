package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun FileAnalysisScreen(){
  Column(Modifier.padding(16.dp)){
    GlassCard(Modifier.fillMaxWidth()){ Column(Modifier.padding(16.dp)){ Text("Research_Paper.pdf • 12 pages"); Text("Summary: This paper explores on-device LLM inference...") } }
  }
}
