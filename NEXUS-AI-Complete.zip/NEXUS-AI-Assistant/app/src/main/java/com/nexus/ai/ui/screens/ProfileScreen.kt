package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun ProfileScreen(){
  Column(Modifier.padding(20.dp)){ Text("John • Premium", style=MaterialTheme.typography.headlineMedium); LinearProgressIndicator(progress=0.62f, modifier=Modifier.fillMaxWidth().padding(top=12.dp)); Text("Storage 6.2GB / 10GB used") }
}
