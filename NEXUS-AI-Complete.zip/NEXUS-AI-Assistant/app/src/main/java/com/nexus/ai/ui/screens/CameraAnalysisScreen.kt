package com.nexus.ai.ui.screens
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable fun CameraAnalysisScreen(){ Box(Modifier.fillMaxSize().padding(16.dp).border(1.dp, Color(0xFF3A7DFF))){ Text("CameraX Preview + ML Kit Object Detection • Bounding boxes • 98% Monstera Detected", color=Color.White) } }
