package com.nexus.ai.ui
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nexus.ai.ui.screens.*
@Composable fun NexusNavGraph(){
  val nav = rememberNavController()
  NavHost(nav, startDestination="splash"){
    composable("splash"){ SplashScreen{ nav.navigate("welcome") } }
    composable("welcome"){ WelcomeScreen{ nav.navigate("setup") } }
    composable("setup"){ FirstTimeSetupScreen{ nav.navigate("download") } }
    composable("download"){ ModelDownloadScreen() }
    composable("chat"){ MainChatScreen() }
    composable("thinking"){ ThinkingScreen() }
    composable("voice"){ VoiceModeScreen() }
    composable("camera"){ CameraAnalysisScreen() }
    composable("image"){ ImageUnderstandingScreen() }
    composable("file"){ FileAnalysisScreen() }
    composable("workspace"){ WorkspaceScreen() }
    composable("notes"){ NotesScreen() }
    composable("tasks"){ TasksScreen() }
    composable("knowledge"){ KnowledgeLibraryScreen() }
    composable("settings"){ SettingsScreen() }
    composable("profile"){ ProfileScreen() }
    composable("models"){ ModelManagerScreen() }
    composable("docked"){ DockedAssistantScreen() }
    composable("overlay"){ FloatingOverlayScreen() }
    composable("command"){ CommandCenterScreen() }
  }
}
