package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun WorkspaceScreen(){ Row(Modifier.fillMaxSize()){ Column(Modifier.weight(0.4f).padding(12.dp)){ Text("AI Assistant"); Divider() }; Column(Modifier.weight(0.6f).padding(12.dp)){ Text("Document / PDF / Code Viewer"); Card{ Text("AI continuously understands visible content", modifier=Modifier.padding(16.dp)) } } } }
