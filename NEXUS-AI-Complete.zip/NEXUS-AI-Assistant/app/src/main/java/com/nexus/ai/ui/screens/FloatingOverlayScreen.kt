package com.nexus.ai.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun FloatingOverlayScreen(){ Box(Modifier.fillMaxSize().background(Color(0xFF11131A))){ GlassCard(Modifier.padding(24.dp).fillMaxWidth().height(320.dp)){ Column(Modifier.padding(16.dp)){ Text("Floating Overlay Chat", color=Color.White); Text("Chat over other apps • Resizable • Transparent glass", color=Color.White.copy(0.6f)) } } } }
