package com.nexus.ai.ui.components
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
enum class OrbState{ IDLE, THINKING, LISTENING, GENERATING }
@Composable fun AiOrb(state:OrbState=OrbState.IDLE, modifier:Modifier=Modifier){
  val infinite = rememberInfiniteTransition(label="orb")
  val scale by infinite.animateFloat(1f,1.08f, infiniteRepeatable(tween(2100, easing=FastOutSlowInEasing), RepeatMode.Reverse), label="scale")
  val glow by infinite.animateFloat(0.6f,1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label="glow")
  Box(modifier.size(140.dp).scale(scale)){
    Box(Modifier.fillMaxSize().blur((18*glow).dp).background(Brush.radialGradient(listOf(Color(0xFF3A7DFF).copy(0.9f), Color(0xFF8A5CFF).copy(0.5f), Color.Transparent)), CircleShape))
    Box(Modifier.fillMaxSize(0.78f).background(Brush.radialGradient(listOf(Color(0xFFF5F7FF), Color(0xFF3CF2FF), Color(0xFF3A7DFF))), CircleShape))
  }
}
