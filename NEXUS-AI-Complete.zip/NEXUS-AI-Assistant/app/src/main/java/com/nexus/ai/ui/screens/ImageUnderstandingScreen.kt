package com.nexus.ai.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun ImageUnderstandingScreen(){
  Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
    Box(Modifier.fillMaxWidth().height(200.dp).background(Color.DarkGray)); Text("Analyzing with NEXUS-Vision 2B")
    GlassCard(Modifier.fillMaxWidth()){ Text("Tags: Plant • Monstera • Indoor • 98% confidence", modifier=Modifier.padding(12.dp)) }
  }
}
