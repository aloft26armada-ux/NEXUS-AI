package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ai.InferenceEngine
import com.nexus.ai.ui.components.AiOrb
import com.nexus.ai.ui.components.GlassCard
import com.nexus.ai.ui.components.OrbState
import kotlinx.coroutines.launch
@Composable fun MainChatScreen(engine: InferenceEngine = com.nexus.ai.ai.FakeEngine()){
  var input by remember{ mutableStateOf("") }; var messages by remember{ mutableStateOf(listOf<Pair<String,Boolean>>()) }
  val scope = rememberCoroutineScope()
  Column(Modifier.fillMaxSize()){
    TopAppBar(title={Text("NEXUS • Core 3.5B Active")})
    LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
      items(messages.size){ i-> val (t,isUser)=messages[i]; GlassCard(Modifier.fillMaxWidth()){ Text(t, modifier=Modifier.padding(14.dp)) } }
    }
    Row(Modifier.padding(12.dp)){ OutlinedTextField(value=input, onValueChange={input=it}, modifier=Modifier.weight(1f), placeholder={Text("Ask anything...")}); Spacer(Modifier.width(8.dp))
      Button(onClick={ val q=input; if(q.isBlank()) return@Button; messages=messages+ (q to true); input=""; scope.launch{ var acc=""; engine.stream(q).collect{ tok-> acc+=tok; messages=messages.dropLast(if(acc==tok)0 else 1) + (acc to false) } } }){ Text("Send") }
    }
    Box(Modifier.padding(16.dp)){ AiOrb(OrbState.IDLE, Modifier.size(64.dp)) }
  }
}
