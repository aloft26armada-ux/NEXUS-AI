package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun CommandCenterScreen(){ LazyVerticalGrid(columns=GridCells.Fixed(2), contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)){
  items(6){ i-> GlassCard{ Column(Modifier.padding(16.dp)){ Text(listOf("AI Status: Active","Memory 2.4GB","Model Core 3.5B","Voice Ready","Knowledge 128 docs","Battery Optimized")[i]) } } }
} }
