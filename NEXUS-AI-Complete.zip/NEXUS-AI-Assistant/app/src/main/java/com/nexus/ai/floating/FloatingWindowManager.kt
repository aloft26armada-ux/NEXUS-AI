package com.nexus.ai.floating
import android.content.Context
import android.graphics.PixelFormat
import android.view.*
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.nexus.ai.ui.components.AiOrb
import com.nexus.ai.ui.components.OrbState
class FloatingWindowManager(private val ctx:Context){
  private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
  private var view: View? = null
  fun showCollapsedOrb(){
    val params = WindowManager.LayoutParams(180,180, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply{ gravity=android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL }
    val compose = ComposeView(ctx).apply{ setContent{ AiOrb(OrbState.IDLE) } }
    view = compose; try{ wm.addView(compose, params) }catch(e:Exception){}
  }
  fun destroy(){ view?.let{ try{ wm.removeView(it)}catch(_:Exception){} }; view=null }
}
