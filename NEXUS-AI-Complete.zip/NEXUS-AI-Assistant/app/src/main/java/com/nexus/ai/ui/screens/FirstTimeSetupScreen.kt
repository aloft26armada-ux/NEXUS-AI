package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun FirstTimeSetupScreen(onNext:()->Unit){
  Column(Modifier.fillMaxSize().padding(24.dp)){
    Text("Setup NEXUS", style=MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(16.dp))
    GlassCard(Modifier.fillMaxWidth()){ Column(Modifier.padding(16.dp)){ Text("Microphone - Voice input"); Switch(checked=true,onCheckedChange={}) } }
    Spacer(Modifier.height(8.dp))
    GlassCard(Modifier.fillMaxWidth()){ Column(Modifier.padding(16.dp)){ Text("Camera - Visual intelligence") } }
    GlassCard(Modifier.fillMaxWidth()){ Column(Modifier.padding(16.dp)){ Text("Overlay - Floating assistant") } }
    Spacer(Modifier.weight(1f)); Button(onClick=onNext, modifier=Modifier.fillMaxWidth()){ Text("Continue") }
  }
}
