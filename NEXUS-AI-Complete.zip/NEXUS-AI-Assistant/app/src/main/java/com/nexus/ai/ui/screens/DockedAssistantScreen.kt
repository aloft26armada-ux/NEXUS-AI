package com.nexus.ai.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable fun DockedAssistantScreen(){ Box(Modifier.fillMaxSize().background(Color(0xFF050507)).padding(16.dp)){ Box(Modifier.fillMaxWidth().height(12.dp).background(Color(0xFF3A7DFF))) ; Text("Edge Dock - Swipe to expand", color=Color.White, modifier=Modifier.padding(top=24.dp)) } }
