package com.nexus.ai.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.ai.ui.components.AiOrb
import com.nexus.ai.ui.components.OrbState
import kotlinx.coroutines.delay
@Composable fun SplashScreen(onDone:()->Unit){
  LaunchedEffect(Unit){ delay(1600); onDone() }
  Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF10122A), Color(0xFF050507))),).padding(24.dp)), contentAlignment=Alignment.Center){
    Column(horizontalAlignment=Alignment.CenterHorizontally){ AiOrb(OrbState.IDLE); Spacer(Modifier.height(28.dp)); Text("NEXUS", color=Color.White, fontSize=28.sp, letterSpacing=6.sp); Text("v1.0 Premium • Local-First", color=Color.White.copy(0.5f)) }
  }
}
