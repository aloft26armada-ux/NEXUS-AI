package com.nexus.ai.ui.screens
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.AiOrb
import com.nexus.ai.ui.components.OrbState
@Composable fun VoiceModeScreen(){
  val inf = rememberInfiniteTransition(label="wave")
  Row(Modifier.fillMaxWidth().padding(32.dp), horizontalArrangement=Arrangement.Center){ repeat(8){ i-> val h by inf.animateFloat(8f,32f, infiniteRepeatable(tween(400+i*70, easing=FastOutSlowInEasing), RepeatMode.Reverse), label="bar$i"); Box(Modifier.padding(3.dp).width(4.dp).height(h.dp)) } }
  Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center){ AiOrb(OrbState.LISTENING) }
}
