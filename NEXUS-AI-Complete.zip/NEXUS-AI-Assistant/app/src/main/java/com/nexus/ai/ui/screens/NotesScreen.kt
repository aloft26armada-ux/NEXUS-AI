package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun NotesScreen(){
  Row(Modifier.fillMaxSize()){ Column(Modifier.weight(0.35f).padding(8.dp)){ Text("Notes"); repeat(3){ Card(Modifier.padding(4.dp).fillMaxWidth()){ Text("Note $it", modifier=Modifier.padding(12.dp)) } } }
  Column(Modifier.weight(0.65f).padding(12.dp)){ TextField(value="AI summarized notes...", onValueChange={}, modifier=Modifier.fillMaxSize()); Row{ Button(onClick={}){ Text("Summarize") }; Button(onClick={}){ Text("Expand") } } } }
}
