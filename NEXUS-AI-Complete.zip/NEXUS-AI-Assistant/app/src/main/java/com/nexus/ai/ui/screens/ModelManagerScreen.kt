package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun ModelManagerScreen(){
  Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)){
    listOf("Core 3.5B - Active","Vision 2B - Downloaded","Voice Small - 124MB").forEach{ Card(Modifier.fillMaxWidth()){ Row(Modifier.padding(16.dp), horizontalArrangement=Arrangement.SpaceBetween){ Text(it); Badge{ Text("OK") } } } }
  }
}
