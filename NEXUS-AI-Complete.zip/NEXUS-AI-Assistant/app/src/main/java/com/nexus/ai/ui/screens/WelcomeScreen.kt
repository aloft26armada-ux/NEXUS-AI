package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun WelcomeScreen(onStart:()->Unit){
 Column(Modifier.fillMaxSize().padding(24.dp)){ Text("Intelligence, that lives with you", style=MaterialTheme.typography.headlineLarge); Spacer(Modifier.height(18.dp))
  GlassCard(Modifier.fillMaxWidth().padding(vertical=8.dp)){ Column(Modifier.padding(16.dp)){ Text("• Offline 3.5B model • Floating OS assistant • Vision + Voice") } }
  Spacer(Modifier.weight(1f)); Button(onClick=onStart, modifier=Modifier.fillMaxWidth().height(56.dp)){ Text("Initialize NEXUS") }
 }
}
