package com.nexus.ai.data.db
import androidx.room.*
@Entity(tableName="messages") data class MessageEntity(@PrimaryKey val id:String, val role:String, val content:String, val createdAt:Long)
@Dao interface MessageDao{ @Query("SELECT * FROM messages ORDER BY createdAt DESC") suspend fun all(): List<MessageEntity>; @Insert suspend fun insert(m:MessageEntity) }
@Database(entities=[MessageEntity::class], version=1) abstract class AppDatabase: RoomDatabase(){ abstract fun messageDao(): MessageDao }
