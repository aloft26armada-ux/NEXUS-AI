package com.nexus.ai
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp
class NexusApp: Application()
