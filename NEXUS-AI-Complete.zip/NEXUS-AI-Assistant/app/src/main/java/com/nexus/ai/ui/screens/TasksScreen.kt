package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun TasksScreen(){
  Column(Modifier.padding(16.dp)){ repeat(4){ Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Row(Modifier.padding(12.dp)){ Checkbox(checked=it==0,onCheckedChange={}); Text("Task ${it+1} - AI extracted from chat") } } } }
}
