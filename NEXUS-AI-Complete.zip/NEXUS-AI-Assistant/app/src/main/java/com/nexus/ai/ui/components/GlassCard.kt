package com.nexus.ai.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable fun GlassCard(modifier:Modifier=Modifier, content:@Composable BoxScope.()->Unit){
  Box(modifier.clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color.White.copy(0.08f), Color.White.copy(0.02f)))).border(1.dp, Color.White.copy(0.08f), RoundedCornerShape(20.dp))){ content() })
}
