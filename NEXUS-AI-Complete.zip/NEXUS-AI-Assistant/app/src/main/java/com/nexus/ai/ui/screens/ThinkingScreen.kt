package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun ThinkingScreen(){
  Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
    Text("Thinking...", style=MaterialTheme.typography.titleLarge)
    Text("• Searching memory (vector DB)"); Text("• Analyzing context 2.4k tokens"); Text("• Reasoning with Core 3.5B")
    LinearProgressIndicator(modifier=Modifier.fillMaxWidth())
  }
}
