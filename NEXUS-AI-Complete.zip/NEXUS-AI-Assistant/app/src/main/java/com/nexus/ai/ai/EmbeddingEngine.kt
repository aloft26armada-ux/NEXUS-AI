package com.nexus.ai.ai
import javax.inject.Inject
class EmbeddingEngine @Inject constructor(){
  // ONNX Runtime all-MiniLM-L6-v2 384d - stub
  fun embed(text:String): FloatArray = FloatArray(384){ 0.01f }
}
