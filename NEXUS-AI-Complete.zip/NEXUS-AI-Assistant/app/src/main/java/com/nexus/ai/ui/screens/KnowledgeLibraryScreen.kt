package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun KnowledgeLibraryScreen(){
  Column(Modifier.padding(16.dp)){ OutlinedTextField(value="", onValueChange={}, placeholder={Text("Search knowledge...")}, modifier=Modifier.fillMaxWidth())
  LazyVerticalGrid(columns=GridCells.Fixed(2), verticalArrangement=Arrangement.spacedBy(8.dp), horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(top=12.dp)){ items(6){ Card{ Text("Doc $it.pdf", modifier=Modifier.padding(16.dp)) } } } }
}
