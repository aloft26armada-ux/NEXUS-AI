package com.nexus.ai.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val NexusDark = darkColorScheme(
  primary = Color(0xFF3A7DFF), secondary = Color(0xFF3CF2FF), tertiary = Color(0xFF8A5CFF),
  background = Color(0xFF050507), surface = Color(0xFF0A0B10), onBackground = Color(0xFFF5F7FF)
)
@Composable fun NexusTheme(content:@Composable ()->Unit){ MaterialTheme(colorScheme=NexusDark, content=content) }
