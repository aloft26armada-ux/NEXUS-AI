package com.nexus.ai.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.GlassCard
@Composable fun ModelDownloadScreen(){
  Column(Modifier.padding(20.dp)){
    GlassCard(Modifier.fillMaxWidth()){ Column(Modifier.padding(16.dp)){
      Text("NEXUS-Core 3.5B"); LinearProgressIndicator(progress=0.68f, modifier=Modifier.fillMaxWidth().padding(top=12.dp)); Text("1.42GB / 2.1GB • 68%", style=MaterialTheme.typography.bodySmall)
      Row(Modifier.padding(top=12.dp)){ OutlinedButton(onClick={}){ Text("Pause") }; Spacer(Modifier.width(8.dp)); Button(onClick={}){ Text("Cancel") } }
    }}
  }
}
