package com.nexus.ai.floating
import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
class NexusFloatingService: Service(){
  private lateinit var windowManager: FloatingWindowManager
  override fun onCreate(){ super.onCreate(); windowManager = FloatingWindowManager(this); startForeground(1, buildNotif()) }
  override fun onStartCommand(intent:Intent?, flags:Int, startId:Int):Int{ windowManager.showCollapsedOrb(); return START_STICKY }
  override fun onBind(intent:Intent?):IBinder? = null
  override fun onDestroy(){ windowManager.destroy(); super.onDestroy() }
  private fun buildNotif(): Notification{ val ch = NotificationChannel("nexus_floating","NEXUS Floating", NotificationManager.IMPORTANCE_LOW); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch); return NotificationCompat.Builder(this,"nexus_floating").setContentTitle("NEXUS Active").setContentText("Tap to expand assistant").setSmallIcon(android.R.drawable.ic_dialog_info).build() }
}
